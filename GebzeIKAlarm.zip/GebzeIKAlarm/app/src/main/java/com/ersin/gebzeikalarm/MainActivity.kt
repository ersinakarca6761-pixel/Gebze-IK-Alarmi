package com.ersin.gebzeikalarm

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        askNotificationPermission()
        scheduleChecks()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val title = TextView(this).apply {
            text = "Gebze İK İlan Alarmı"
            textSize = 25f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "\nBölgeler: Gebze • Çayırova • Darıca • Dilovası\n\n" +
                "Takip: İŞKUR, Kariyer.net, Eleman.net, Yenibiriş, Indeed, SecretCV, Jooble ve LinkedIn\n\n" +
                "Kontrol sıklığı: 60 dakika\n\n" +
                "Yeni eşleşme bulunduğunda telefon bildirimi gönderilir. " +
                "Android pil tasarrufu kontrol saatini geciktirebilir."
            textSize = 16f
        }
        val now = Button(this).apply {
            text = "Şimdi kontrol et"
            setOnClickListener {
                JobWorker.runNow(this@MainActivity)
                info.text = info.text.toString().substringBefore("\n\nSon kontrol isteği") +
                    "\n\nSon kontrol isteği: gönderildi"
            }
        }
        val status = TextView(this).apply {
            text = "\nDurum: Saatlik takip etkinleştirildi.\n"
            textSize = 15f
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(now)
        layout.addView(status)
        setContentView(layout)
    }

    private fun scheduleChecks() {
        val request = PeriodicWorkRequestBuilder<JobWorker>(60, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "gebze_ik_hourly_check",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = android.app.NotificationChannel(
                JobWorker.CHANNEL_ID, "Yeni iş ilanları",
                android.app.NotificationManager.IMPORTANCE_HIGH
            )
            getSystemService(android.app.NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }
}
