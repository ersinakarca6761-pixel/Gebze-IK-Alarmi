package com.ersin.gebzeikalarm

import android.content.Context
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import javax.xml.parsers.DocumentBuilderFactory

class JobWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        return try {
            val prefs = applicationContext.getSharedPreferences("seen_jobs", Context.MODE_PRIVATE)
            val query = ""insan kaynakları" OR bordro OR bordrolama OR "personel özlük" OR puantaj " +
                "(Gebze OR Çayırova OR Darıca OR Dilovası) "
            val domains = listOf(
                "iskur.gov.tr", "kariyer.net", "eleman.net", "yenibiris.com",
                "indeed.com", "secretcv.com", "jooble.org", "linkedin.com"
            )
            var newCount = 0
            for (domain in domains) {
                val q = "$query site:$domain"
                val encoded = URLEncoder.encode(q, "UTF-8")
                val feed = "https://news.google.com/rss/search?q=$encoded&hl=tr&gl=TR&ceid=TR:tr"
                val items = readFeed(feed)
                for ((title, link, description) in items) {
                    val combined = (title + " " + description).lowercase()
                    val hasArea = listOf("gebze", "çayırova", "cayırova", "darıca", "dilovası", "dilovasi")
                        .any { combined.contains(it) }
                    val hasRole = listOf("insan kaynak", "bordro", "bordrolama", "özlük", "personel işleri",
                        "puantaj", "ik uzman", "ik sorumlu").any { combined.contains(it) }
                    val key = link.hashCode().toString()
                    if (hasArea && hasRole && !prefs.getBoolean(key, false)) {
                        prefs.edit().putBoolean(key, true).apply()
                        showNotification(title, domain, link)
                        newCount++
                    }
                }
            }
            prefs.edit().putLong("last_check", System.currentTimeMillis()).apply()
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    private fun readFeed(address: String): List<Triple<String, String, String>> {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("User-Agent", "GebzeIKAlarm/1.0")
        }
        try {
            connection.inputStream.use { stream ->
                val factory = DocumentBuilderFactory.newInstance()
                factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
                val doc = factory.newDocumentBuilder().parse(stream)
                val nodes = doc.getElementsByTagName("item")
                val result = mutableListOf<Triple<String, String, String>>()
                for (i in 0 until nodes.length) {
                    val item = nodes.item(i)
                    val children = item.childNodes
                    var title = ""; var link = ""; var desc = ""
                    for (j in 0 until children.length) {
                        val node = children.item(j)
                        when (node.nodeName) {
                            "title" -> title = node.textContent ?: ""
                            "link" -> link = node.textContent ?: ""
                            "description" -> desc = node.textContent ?: ""
                        }
                    }
                    if (title.isNotBlank() && link.isNotBlank()) result.add(Triple(title, link, desc))
                }
                return result
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun showNotification(title: String, source: String, link: String) {
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(link))
        val pending = PendingIntent.getActivity(
            applicationContext, link.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Yeni İK ilanı bulundu!")
            .setContentText(title.take(110))
            .setStyle(NotificationCompat.BigTextStyle().bigText("$title\nKaynak: $source\nAçmak için dokun."))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(link.hashCode(), notification)
    }

    companion object {
        const val CHANNEL_ID = "job_alerts"
        fun runNow(context: Context) {
            val req = OneTimeWorkRequestBuilder<JobWorker>().setInitialDelay(0, TimeUnit.SECONDS).build()
            WorkManager.getInstance(context).enqueue(req)
        }
    }
}
