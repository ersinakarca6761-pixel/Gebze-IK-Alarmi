# Gebze İK İlan Alarmı

Android uygulaması: Gebze, Çayırova, Darıca ve Dilovası için İK/bordro ilanlarını saatlik kontrol etmeyi dener ve yeni eşleşmelerde bildirim üretir.

## Önemli sınırlama
Bu ilk sürüm, Google News RSS arama sonuçlarını kaynak sitelere göre filtreler. Bu, İŞKUR, Kariyer.net, Eleman.net, Yenibiriş, Indeed, SecretCV, Jooble ve LinkedIn'in resmi API entegrasyonu değildir. Arama motorunun indekslediği ilanları bulabilir; her ilanı yakalayacağı veya her sitenin tüm ilanlarına erişeceği garanti edilemez. Bazı siteler giriş, robots veya erişim kısıtları uygular.

## APK üretme
1. Bu ZIP'i bir GitHub deposuna yükleyin.
2. Depoda Actions sekmesini açın.
3. `Build Android APK` iş akışını çalıştırın.
4. Tamamlanınca `Gebze-IK-Alarmi-APK` adlı artifact'i indirin.
5. ZIP içindeki `app-debug.apk` dosyasını Android telefona aktarın ve yükleyin.
6. İlk açılışta bildirim izni verin.

## Takvim
Android WorkManager 60 dakikalık periyodik kontrol ister. Android işletim sistemi pil/doze koşullarına göre çalıştırmayı geciktirebilir; tam saat garantisi vermez.

## Sürüm
1.0 — debug APK; Play Store imzalı yayın paketi değildir.
